#!/usr/bin/env python
# -*- coding: utf-8 -*-

from pelita.player import SimpleTeam
from .kickass_agent import KickassPlayer

def factory():
    return SimpleTeam("My KIS Team",
                      KickassPlayer({'teamfood.multiplier':2,
                                     'food.multiplier':1,
                                     'victim.radius':20,
                                     'teamfood.exponent':1.}), 
                      KickassPlayer())
