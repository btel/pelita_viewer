#!/usr/bin/env python
#coding=utf-8

import numpy as np
from pelita.player import AbstractPlayer
from pelita.datamodel import stop
from pelita.datamodel import Wall
np.set_printoptions(precision=2, suppress=True)

NEIGHBOURS = [(-1,0), (1,0), (0,-1), (0,1)]

def update_params(param_dict, **kwargs):
    PARAMS.update(param_dict)
    PARAMS.update(kwargs)


class KickAssHQ(object):

    _shared_state = {'agents':[]} 

    def __new__(cls, *a, **k):
        obj = super(KickAssHQ, cls ).__new__(cls, *a, **k)
        obj.__dict__ = cls._shared_state 
        return obj
    
    def register_agent(self, agent):
        if not self.agents:
            self.max_team_food = None 
            self.max_enemy_food = None
        self.agents.append(agent)

    @property
    def agent(self):
        return self.agents[0]

    def get_wall_map(self):
        agent = self.agent
        wall_pos = agent.current_uni.maze.pos_of(Wall)
        walls = self._position_to_map(wall_pos)
        return walls

    def get_food_map(self):
        food_pos = self.agent.enemy_food
        if self.max_enemy_food is None:
            self.max_enemy_food = len(food_pos)
        has_food  = self._position_to_map(food_pos)
        food_dist_map = has_food-1
        frac_left = len(food_pos)*1./self.max_enemy_food
        food_map = self._calc_distance_map(food_dist_map)
        #food_map = food_map*1./frac_left**PARAMS['food.exponent']
        return food_map
    
    def get_team_food_map(self, exponent):
        food_pos = self.agent.current_uni.team_food(self.agent.me.team_index) 
        if self.max_team_food is None:
            self.max_team_food = len(food_pos)
        has_food  = self._position_to_map(food_pos)
        food_dist_map = has_food-1
        food_map = self._calc_distance_map(food_dist_map)
        frac_left = len(food_pos)*1./self.max_team_food
        food_map = food_map*1./(frac_left)**exponent
        return food_map
    
    def _get_enemy_pos(self):
        gps_data = {}
        for agent in self.agents:
            for enemy in agent.enemy_bots:
                gps_data.setdefault(enemy.index, []).append(
                    {'pos': np.array(enemy.current_pos),
                     'noisy': enemy.noisy})
        
        positions = []
        for enemy in gps_data.values():
            if enemy[0]['noisy'] and enemy[1]['noisy']:
                positions.append((enemy[0]['pos']+enemy[1]['pos'])/2.)
            elif not enemy[0]['noisy']:
                positions.append(enemy[0]['pos'])
            else:
                positions.append(enemy[1]['pos'])

        return map(tuple, positions)

                
    def get_ghost_map(self, radius):
        ghost_pos = [pos for pos in self._get_enemy_pos()
                                     if not self.agent.team.in_zone(pos)]
        ghost_map = self._position_to_map(ghost_pos)-1
        #radius = PARAMS['ghost.radius']
        ghost_dist_map = self._calc_distance_map(ghost_map,
                                                 radius)
        ghost_dist_map[(ghost_dist_map<2) & (ghost_dist_map>=0)] = -1000
        ghost_dist_map = np.where(ghost_dist_map==-1, 0,
                                  -ghost_dist_map+radius) 
        return ghost_dist_map

    def get_victim_map(self, radius):
        victim_pos = [pos for pos in self._get_enemy_pos()
                      if self.agent.team.in_zone(pos)]
        victim_map = self._position_to_map(victim_pos)-1
        #radius = PARAMS['victim.radius']
        victim_dist_map = self._calc_distance_map(victim_map,
                                                  radius)
        victim_dist_map = np.where(victim_dist_map==-1, radius,
                                  victim_dist_map) 

        return victim_dist_map

    def get_partner_map(self, me, radius):
        partner = self._get_partner(me)
        partner_pos = partner.current_pos
        map = self.empty_map() - 1
        map[partner_pos[0], partner_pos[1]] = 0

        #radius = PARAMS['partner.radius']
        map = self._calc_distance_map(map, radius)
        map = np.where(map==-1, 0, -map+radius) 
        return map

    def _get_partner(self, me):
        for agent in self.agents:
            if not agent == me:
                return agent
        raise Exception("NoSuchAgent")


    def _position_to_map(self, pos):
        wall_map = self.empty_map() 
        for x, y in pos:
            wall_map[x,y] = 1
        return wall_map

    def empty_map(self):
        return np.zeros(self.agent.current_uni.maze.shape,
                        dtype=np.int32)

    def _calc_distance_map(self, distance_map, max_dist=None):
        """Return a distance map.
        
        It takes into account the labyrint walls and does not overwrite the
        values at their positions.
        
        distance_map -- 2d array where the values are either distance 0 or
            negative. The negative entries will then be overwritten with the
            correct distance value.
        max_dist -- Integer that if provided (default is None) stops the
            distance calculation at the given value. The values at the
            unvisited positions are not modified.
        """
        wall_map = self.get_wall_map()
        map_indices = self.agent.current_uni.maze.positions

        updated_indices = [index for index in map_indices
                           if not distance_map[index] and
                              not wall_map[index]]
        unkown_indices = [index for index in map_indices
                          if distance_map[index] and not wall_map[index]]
        current_dist = 0
        while unkown_indices:
            current_dist += 1
            if max_dist and (current_dist > max_dist):
                return distance_map
            old_updated_indices = updated_indices
            updated_indices = []
            for index in old_updated_indices:
                for neigbour in NEIGHBOURS:
                    nb_index = (index[0] + neigbour[0], index[1] + neigbour[1])
                    if nb_index in unkown_indices:
                        distance_map[nb_index] = current_dist
                        updated_indices.append(nb_index)
                        unkown_indices.remove(nb_index)
        return distance_map



class KickassPlayer(AbstractPlayer):
   
    def __init__(self, params=None):
        self.hq = KickAssHQ()
        self.hq.register_agent(self)
        self._trace_map = None
        self.count =0
        self.params = {
            'food.multiplier':2,
            'teamfood.multiplier':0.,
            'teamfood.exponent':0,
            'food.exponent':0,
            'ghost.multiplier':2,
            'partner.radius': 5,
            'ghost.radius':5,
            'victim.radius':5,
            'victim.multiplier':3,
            'partner.multiplier': 2,
            'wall.multiplier': 10000,
            'trace.decay': 0.1,
            'trace.increment': 1.,
            'trace.multiplier': 1
        }
        if params:
            self.params.update(params)
  
    @property
    def trace_map(self):
        if self._trace_map is None:
            self._trace_map = self.hq.empty_map().astype(np.float32)
        return self._trace_map

    def update_trace(self):
        x,y = self.current_pos
        self._trace_map -= self.params['trace.decay']
        self._trace_map[self._trace_map<0] = 0
        self._trace_map[x,y] += self.params['trace.increment']

    def neighbourhood(self, map):
        x,y = self.current_pos
        return map[x-1:x+2,y-1:y+2]

    def get_move(self):
        
        walls = self.hq.get_wall_map()
        food = self.hq.get_food_map()
        team_food = self.hq.get_team_food_map(self.params['teamfood.exponent'])
        partner_map = self.hq.get_partner_map(self,self.params['partner.radius'])
        ghost_map = self.hq.get_ghost_map(self.params['ghost.radius'])
        victim_map = self.hq.get_victim_map(self.params['victim.radius'])
        map = self.hq.empty_map().astype(np.float32)
        map += partner_map*self.params['partner.multiplier']
        map += walls*self.params['wall.multiplier']
        map += food*self.params['food.multiplier']
        map += team_food*self.params['teamfood.multiplier']
        map += ghost_map*self.params['ghost.multiplier']
        map += victim_map*self.params['victim.multiplier']
        map += self.trace_map*self.params['trace.multiplier']
        best_directions = []
        for move in self.legal_moves:
            i = move[0] + self.current_pos[0]
            j = move[1] + self.current_pos[1]
            value = map[i,j]
            best_directions.append((value, move))
        best_directions.sort()
        best_directions= best_directions[::-1]
        best_value, best_direction = best_directions.pop()
        #if best_direction == stop:
        #    best_value, best_direction = best_directions.pop()
        self.update_trace()
        #print self.neighbourhood(map).T
        return best_direction


def map_print():
    pass
